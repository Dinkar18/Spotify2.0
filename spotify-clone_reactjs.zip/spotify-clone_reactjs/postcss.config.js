export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
// Post Css configuration